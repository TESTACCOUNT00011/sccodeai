# BYTE & PRINT — Event-Driven Programming Final Project

> “Print it, pick it up, and grab what you need.”

An interactive, **database-free student business website** for the Byte & Print concept described in the group's feasibility study near Cebu Eastern College, Cebu City. Built with semantic HTML, responsive CSS, and **PyScript (Python in the browser)** to demonstrate Event-Driven Programming.

## Team / founders

- **Celestino II D. Regis** — home/branding & service recommendation
- **Lance Steven G. Yano** — services & real-time cost calculator
- **Jhon Kyle T. Ramos** — pickup request & validation
- **Jay C. Villaceran** — shop catalog, search, filters & basket

These are project workstream assignments. GitHub contributions must be made authentically by the people named.

## Run this project

1. Download or clone the project.
2. In a terminal, navigate to the directory containing `index.html`.
3. Run: `python -m http.server 8000`
4. Open [http://localhost:8000](http://localhost:8000) in an up-to-date browser with internet access.
5. Explore the five pages and try the PyScript interactions.

No Python package installation, npm, backend or database is required to **host** the site. The CDN provides PyScript and the runtime at page load, so initial use **does require an internet connection**. Opening `index.html` directly via `file://` is not recommended due to browser module/file restrictions.

## Pages

| Page | Interactive features |
|---|---|
| `index.html` | Pick a student need; click handler updates recommendation |
| `services.html` | Price calculator updates on field changes; checks quantities |
| `pickup.html` | Print-cost estimate; file-name preview; validated, printable local request draft |
| `shop.html` | Live search, category filters, add-to-basket, clear basket and total |
| `about.html` | Concept, founders, proposed location and feasibility-study findings |

## Important prototype limits

**No file upload, order submission, reservation, stock control, purchase, online payment or email happens here.** The pickup form creates a draft **within the browser only** and lets customers print/save it. Choosing a file reveals its name locally, but file bytes are not transmitted or stored by the website. Use an actual shop-controlled communication channel outside this prototype to submit documents. This project does not invent a Messenger account, business email or live branch.

The pricing for printing, scanning, computer rental and pickup uses the proposed rates in the feasibility report. Individual shop-item prices are illustrative for the interactive catalog demo.

## Tech stack

- **HTML5** — five linked pages
- **CSS3** — responsive design, illustrations and layout
- **PyScript** — version pinned to `2026.7.3` CDN; event decorators (`@when`), DOM updates, Python business logic
- **Python `unittest`** — six offline logic checks with mock DOM, no external dependencies

Reference for PyScript syntax: https://docs.pyscript.net/2026.7.3/

## Project structure

```text
index.html / services.html / pickup.html / shop.html / about.html
styles.css
assets/mark.svg
scripts/home.py
scripts/services.py
scripts/pickup.py
scripts/shop.py
tests/test_logic.py
PROJECT_PLAN.md
README.md
presentation/Byte_and_Print_EDP_Presentation.pptx
presentation/PRESENTATION_SCRIPT.md
presentation/screenshots/...
```

## Test

`python -m unittest discover -s tests -v`

The included six offline tests passed when the starter artifact was generated. They validate key Python calculations, receipt logic, filtering, and the click recommendation. **A complete browser-level test of the external PyScript CDN could not be carried out in the generation environment; the group must verify live interactions in Chrome/Edge before submission.** Screenshots are accurate captures of the authored HTML/CSS and Python source, not proof of the PyScript CDN executing live.

## Publish to GitHub

Create a **public** GitHub repository, add these files at the **repository root** (so `index.html` is at root), and invite all four members as collaborators. Each member must **make their own real commits** rather than merely appearing on the collaborator list. If using GitHub Pages, set Settings > Pages > Deploy from a branch > `main` > `/(root)`. The completed recorded presentation should be included or linked according to the instructor's directions. Submit only the public repository URL.

See [PROJECT_PLAN.md](PROJECT_PLAN.md) for the detailed role plan, and [PRESENTATION_SCRIPT.md](presentation/PRESENTATION_SCRIPT.md) for a full slide-by-slide speaking script.
