# Byte & Print — EDP Final Project Plan

## Project definition

**Business:** Byte & Print — a proposed student-focused computer, document, supplies, and snack convenience hub near Cebu Eastern College on Leon Kilat St., Pahina Central, Cebu City.

**Tagline:** “Print it, pick it up, and grab what you need.”

**Source:** The group's *Byte & Print* feasibility study (submitted September 29, 2026) and the EDP final project instructions.

**Build type:** public static business website, five pages, HTML + CSS + Python via PyScript 2026.7.3. No framework, database, hosting backend, or authentication.

## Page-by-page plan (implemented)

| Route | Purpose | Event-driven feature | Assigned workstream |
|---|---|---|---|
| `index.html` | Introduce the business and direct customers to services | `click` event changes service recommendation on the page | Regis |
| `services.html` | List proposed service rates and give estimates | `input` / `change` events recalculate page, copy, rental and pickup costs | Yano |
| `pickup.html` | Prepare a simulated print pickup request | `input`, `change`, `submit`, `click` for quote, filename preview, validation, local printable summary | Ramos |
| `shop.html` | Display school supplies, snacks and drinks | `click` and `input` events filter products, search, add to basket and recalculate total | Villaceran |
| `about.html` | Business concept, founders, location and survey evidence | Informational page; no artificial interaction needed | Regis / all team review |

## Business prices from the study

| Service | Proposed unit rate |
|---|---:|
| Black & white printing | ₱2.50 per page |
| Color printing | ₱8.50 per page |
| Photocopying | ₱2.50 per page |
| Scanning | ₱10.00 per page |
| Computer rental | ₱20.00 per hour |
| Online pickup handling | ₱15.00 per order |

Retail product prices in `shop.html` are **illustrative website-demo prices**, because the feasibility study provides only daily retail assumptions, not individual product prices.

## Customer journey and no-database boundary

1. Visit the website and choose a service.
2. Use the Python-driven service calculator to see an estimate.
3. Fill the pickup form with print settings and a preferred date/time.
4. Optionally select a local file; the browser shows only its filename and **does not upload its contents**.
5. Generate and print/save a **local request draft**. No order is sent; staff availability is not checked.
6. In a real rollout, send the actual document and confirm pickup through a shop-operated channel. Those integrations are outside this static academic prototype.
7. Browse the demo shop and add items to a calculator basket. There is no checkout, stock tracking, or payment processing.

## Event-driven programming coverage

- **Click:** home recommendation tabs; product category buttons; add and clear basket; print draft.
- **User input:** number of pages/copies, product search, optional instructions.
- **Change:** print type, pickup fee, file selection.
- **Form submit:** built-in validation + custom limits/date checks + local summary generation.
- **Calculations:** price × units × copies + pickup fee; basket quantity × item price.
- **Dynamic DOM:** updated text, visible cards, receipts, controls and validation messages.

## Suggested delivery and commit plan

These are **assigned tasks, not proof of past authorship**. Each member should review the module, make meaningful code edits, test their pages, then commit/push their own actual work using their personal GitHub account.

| Member | Own / review these files | Demonstrate in video | Example truthful commit after personal edits |
|---|---|---|---|
| Celestino II D. Regis | `index.html`, `about.html`, `scripts/home.py` plus brand/style review | Page navigation, service recommendation | `feat: refine home page and recommendation interaction` |
| Lance Steven G. Yano | `services.html`, `scripts/services.py` | Price calculations and live input events | `feat: validate and improve service quote calculator` |
| Jhon Kyle T. Ramos | `pickup.html`, `scripts/pickup.py` | Form validation, fee calculation, printable draft | `feat: improve pickup request validation and summary` |
| Jay C. Villaceran | `shop.html`, `scripts/shop.py` | Category filter, search, cart total | `feat: refine shop filters and basket calculator` |

**Shared reviews:** CSS responsiveness, mobile QA, documentation and video. Everyone should approve final changes and have authentic commits or pull requests visible on GitHub.

## Presentation plan

- Format: recorded group video, minimum 10 minutes, all four members appear.
- Deck: `presentation/Byte_and_Print_EDP_Presentation.pptx`; each slide has speaker notes.
- Printable script: `presentation/PRESENTATION_SCRIPT.md`.
- Screenshots: `presentation/screenshots/code-regis.png`, `code-yano.png`, `code-ramos.png`, `code-villaceran.png` captured from the assigned Python modules (not screenshots of Git history).
- Flow: introduction; business process; site walkthrough; PyScript implementation; contribution assignments; testing; repository submission.
- The script uses first-person descriptions of **assigned work**, which members must verify, actually perform and adapt before recording.

## Submission checklist

- [ ] Each member personally reviews, edits, commits and pushes assigned code.
- [ ] Verify PyScript buttons/forms in a real browser with internet access.
- [ ] Run offline unit tests: `python -m unittest discover -s tests -v`.
- [ ] Create one **public** GitHub repository with `index.html` at its root.
- [ ] Invite all four teammates as collaborators and verify meaningful contributions/commit history.
- [ ] Optional: enable GitHub Pages (Deploy from branch > main > root).
- [ ] Record a video of at least 10 minutes and show all members on camera.
- [ ] Provide screenshots of each member's **real, updated** contributions, plus actual GitHub commit evidence if requested.
- [ ] Add the recorded video to the repository or link it per instructor instructions (large videos may require an externally hosted link).
- [ ] Submit **only the public GitHub repository URL** as instructed.
