# Byte & Print — Recorded EDP Presentation Script

**Target length:** Approximately 13–16 minutes including screen transitions and demonstrations. Minimum required by instructor: 10 minutes.

**Before recording:** These first-person scripts describe assigned workstreams. Every member must actually review, edit, commit and understand the module they present; adapt the wording to match what they truly did. Every member must appear on camera. Screenshots come from source files, not from GitHub activity.

**Business status:** This is a business concept and static demonstration. No actual website order, file upload, stock check or payment occurs.

## Slide 01 — Byte & Print
**Speaker:** Celestino II D. Regis  |  **Target:** 0:45  |  **Section:** INTRODUCTION

Good day, everyone. We are the group behind Byte & Print, a proposed student convenience hub near Cebu Eastern College. I am Celestino II D. Regis, and I am presenting together with Lance Steven G. Yano, Jhon Kyle T. Ramos, and Jay C. Villaceran. Our Event-Driven Programming final project is a business website based on our earlier feasibility study. It combines printing, pickup preparation, computer access, school supplies, and snacks. Our guiding message is “Print it, pick it up, and grab what you need.” In this video, all four of us will explain the business, demonstrate the website, and discuss our individual Python modules.

## Slide 02 — Why Byte & Print?
**Speaker:** Celestino II D. Regis  |  **Target:** 0:55  |  **Section:** BUSINESS CONCEPT

Our feasibility study identified a simple student problem. Someone might need to print an assignment, use a computer, buy a pen, and grab a snack, but those services can require separate stops. Waiting at print shops also becomes a problem during busy school weeks. Byte & Print was designed around convenience: a single location with document services, computer rental, school supplies, and snacks. The study gathered forty-nine survey responses, and eighty-seven point eight percent rated online pickup printing as very convenient. These figures support the concept, but they are research findings and assumptions, not proof that a real operating store is already open.

## Slide 03 — Five simple pages
**Speaker:** Celestino II D. Regis  |  **Target:** 0:55  |  **Section:** SITE MAP

I planned the website around five pages so visitors can find their needs quickly. Home introduces the brand and includes an interactive recommendation selector. Services lists prices and provides a cost calculator. Pickup Printing has a form that produces a request draft. Shop offers a sample product catalog with filters and a basket. Finally, About Us explains our business concept and displays all four founders. The pages use the same navigation bar and footer. This structure is intentionally simple because the EDP requirement is about meaningful user interaction with PyScript, not about having a large backend or database.

## Slide 04 — Home page: click events
**Speaker:** Celestino II D. Regis  |  **Target:** 1:10  |  **Section:** MY CODE EXPLANATION

For my assigned workstream, I handled the Home page, the branding direction, and the service recommendation logic. Here is the actual source excerpt from home.py. The dictionary holds three suggestions: printing, computer access, and shopping. The @when decorator listens for a click on a choice button. Python reads the button's data-need attribute, finds the matching suggestion, removes the previous active state, and changes the icon, title, description, and link. This demonstrates an event, a Python condition-based lookup, and an immediate DOM update. During the demo, I can click each need and show how the recommendation changes without refreshing the page.

## Slide 05 — Built for event-driven Python
**Speaker:** Lance Steven G. Yano  |  **Target:** 0:55  |  **Section:** TECH STACK

I am Lance Steven G. Yano. I will explain the technical structure and the service cost calculator. We deliberately used a small technology stack. HTML defines the actual pages and forms. CSS makes the website responsive and gives all pages a consistent look. PyScript loads Python in the browser, so it can listen to clicks, input changes, and form submissions. We used the @when decorator to attach Python functions to those events, then updated the Document Object Model through Python. There is no Flask server, database, user account, or cloud storage. For this school requirement, our main goal was to show a real event-driven interaction using Python.

## Slide 06 — Student-friendly service rates
**Speaker:** Lance Steven G. Yano  |  **Target:** 0:55  |  **Section:** BUSINESS SERVICES

Our services page uses rates from the Byte & Print feasibility report. Black-and-white printing is two pesos and fifty centavos per page, color printing is eight pesos and fifty centavos, and photocopying is two pesos and fifty centavos. Scanning is ten pesos per page, computer rental is twenty pesos per hour, and the proposed pickup handling fee is fifteen pesos per order. We label them as proposed prices because this website is still an academic prototype. Rather than giving customers only a static price list, I added an interactive calculator so users can test how pages, copies, service type, and the handling fee affect the estimate.

## Slide 07 — Live estimate calculator
**Speaker:** Lance Steven G. Yano  |  **Target:** 0:55  |  **Section:** WEBSITE DEMONSTRATION

On the Services page, I select a service and enter the quantity. For example, four color pages with two copies gives eight total printed pages. At eight pesos and fifty centavos each, the printing subtotal is sixty-eight pesos. If we check the pickup option, the estimate becomes eighty-three pesos. The page also adjusts its fields when computer rental is selected: it uses hours and hides the copies field and pickup option. If someone types an invalid amount, the calculator shows a prompt instead of a misleading total. This is the kind of immediate feedback we wanted to demonstrate in Event-Driven Programming.

## Slide 08 — Python recalculates the total
**Speaker:** Lance Steven G. Yano  |  **Target:** 1:05  |  **Section:** MY CODE EXPLANATION

This screenshot is from services.py, my assigned Python module. The update_quote function reads the selected service and decides whether the unit is pages or hours. It retrieves validated positive numbers, finds the correct price in the rates dictionary, and adds the fifteen-peso pickup handling fee only when that option is appropriate. Then it writes the formatted amount to the total element. Notice the @when decorators near the bottom: input events run when the user types, and change events run when the selected service or pickup checkbox changes. This separates the browser events from the pricing rules and is the main code I would highlight.

## Slide 09 — From instructions to pickup
**Speaker:** Jhon Kyle T. Ramos  |  **Target:** 0:55  |  **Section:** BUSINESS PROCESS

I am Jhon Kyle T. Ramos, and my assigned area is the Pickup Printing page. In the proposed business process, a customer prepares a file, specifies the number of pages and copies, confirms the estimated price, and arranges pickup with the shop. We translated the preparation part into a website form. The student enters contact details and print preferences, then generates a readable request summary. This helps illustrate how advance preparation could reduce confusion and waiting. The important limitation is that our static website does not send the order or file; real submission and shop confirmation must happen through a verified communication channel.

## Slide 10 — The pickup form
**Speaker:** Jhon Kyle T. Ramos  |  **Target:** 1:00  |  **Section:** WEBSITE DEMONSTRATION

Here is the Pickup Printing form. First, I enter the customer name and email. Next, I choose black-and-white or color, paper size, pages, copies, and a preferred pickup date and time. The price estimate updates automatically whenever quantities or print type change. There is also an optional document picker. Choosing a file displays the filename, but nothing is uploaded. I can add instructions, choose a preferred payment method, and confirm that I understand this is a demo. After the form passes validation, Python creates a summary that I can print or save as a PDF. This demonstrates multiple event types on one page.

## Slide 11 — Useful demo, clear limits
**Speaker:** Jhon Kyle T. Ramos  |  **Target:** 0:55  |  **Section:** DESIGN DECISION

Since we are not using a server or database, I made the request experience transparent. We do not claim an order is submitted. We do not collect an actual payment, verify store availability, or transmit a document. The file picker shows only a local filename. The summary states clearly that it is not submitted, and the user must contact a real shop channel for confirmation. Validation is also important: required fields must be complete, pages and copies have reasonable limits, and past pickup dates are rejected. These checks help prevent accidental or confusing information and give us useful examples of event-driven input handling.

## Slide 12 — Form submit event + validation
**Speaker:** Jhon Kyle T. Ramos  |  **Target:** 1:05  |  **Section:** MY CODE EXPLANATION

This is the relevant code from pickup.py. The @when submit decorator attaches create_draft to the form's submission. The first instruction, preventDefault, stops the browser's normal submit behavior, because we do not have a server endpoint. Next, checkValidity handles required fields, the get_amounts helper checks numeric limits, and a date comparison blocks a pickup date in the past. Only after those checks do we calculate the amount and build the local summary using textContent. That is safer than inserting raw user text as HTML. This code shows form submission events, validation, calculations, and dynamic output in one workflow.

## Slide 13 — Search, filter, and add
**Speaker:** Jay C. Villaceran  |  **Target:** 1:00  |  **Section:** WEBSITE DEMONSTRATION

I am Jay C. Villaceran, and I handled the assigned Shop page. It features sample school supplies, snacks, and drinks because our business concept is more than a print shop. Visitors can filter by product category or type a keyword in the search box. Python hides items that do not match and updates the number of visible results. They can also click Add to place an item in a mini basket, and the total updates immediately. Clicking Clear Basket resets the estimate. The individual retail prices are for demonstration only, because our feasibility report does not provide a separate selling price for each store item.

## Slide 14 — A basket powered by click events
**Speaker:** Jay C. Villaceran  |  **Target:** 1:10  |  **Section:** MY CODE EXPLANATION

Here is the add-to-basket logic in shop.py, along with the clear action. The @when click decorator connects every Add button to the add_to_basket function. Python reads the item's data-name and data-price attributes and saves the item in a local dictionary. If the item already exists, the quantity is increased. The render_basket function then multiplies quantity by price and updates the displayed total. The clear button empties the dictionary and refreshes the display. In the same file, separate click and input listeners also run the product category filter and text search. This is a good demonstration of simple state management without a database.

## Slide 15 — Tests and real contributions
**Speaker:** Jay C. Villaceran  |  **Target:** 1:05  |  **Section:** QUALITY & GITHUB

For final checking, the starter project includes six offline Python logic tests that passed for the calculator, pickup draft and date validation, shop basket, and home recommendation. We also prepared screenshots of the actual source code assigned to each member. But a screenshot alone is not proof that someone made a GitHub contribution. Before submission, each member must review and make meaningful edits to their own file, commit those edits under their own account, and push them to our public repository. We also need to retest the PyScript buttons and forms in a real browser with an internet connection before recording. Our instructor will check the public commit history.

## Slide 16 — Simple stack. Clear impact.
**Speaker:** Jay C. Villaceran  |  **Target:** 0:50  |  **Section:** CLOSING & SUBMISSION

To summarize, Byte & Print translates our feasibility study into a five-page business website. We kept the design clear and the stack simple: HTML, CSS, and PyScript. We demonstrated service selection, cost calculation, form validation, printable request summaries, product filtering, and a basket total. All these functions respond to user actions in the browser without a database. Our next steps are to finish authentic member contributions in one public GitHub repository, verify the live browser behavior, record every member appearing and speaking, and add the video according to our instructor's directions. The required submission is only the public repository link. Thank you for watching our presentation.

## Recording checklist

- Show all four members on camera during their own parts.
- Capture a short real browser demonstration for Home, Services, Pickup and Shop.
- Point to the source code on screenshots, then show the result in the browser.
- Run and verify PyScript with internet in Chrome/Edge before recording.
- Include the recorded video in or link it from the public repository per instructor instructions.
- Every member must make real commits. Do not fabricate GitHub contribution history.
- Submit ONLY the public GitHub repository link.
